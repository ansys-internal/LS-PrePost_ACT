Readme.txt
Name of the extension: Model Convert

ANSYS Workbench LSPConverter Extension wizard build date 2021-04-29

This version provided is for 2021R1 for customers who are running ANSYS 2021R1.

Model Convert is an act extension wizard. It can convert external model type from 

abaqus,radioss,nastran,ideas,pamcrash and fluent_msh file to LS-Dyna keyword format via LS_PrePost.

After the conversion, there is an optional step which use the converted keyword file to build a LS-DYNA project in Workbench.



