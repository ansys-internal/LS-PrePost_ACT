Readme.txt
Name of the extension: LST_PrePost 2022.2
ANSYS ACT LST_PrePost build date 2022-11-22

This version provided is compatible with ANSYS 2022 R2.

LST_PrePost is an act extension of ANSYS. It allow LS-Dyna user launch LS-PrePost to do postprocessing within Ansys Workbench using project schematic.
It also build a mechanical toolbar LST_LSPP which are includes 6 icons(run features of LS-PrePost in Mechanical ).
  
